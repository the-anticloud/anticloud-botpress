# Tutorial — Developers — BOTPRESS

**Company:** Anticloud FZ LLE
**Model:** PAX L5 Narrow L2 General 27B
**Project:** BOTPRESS | Category: CHAT_PLATFORMS
**Upstream:** https://github.com/nicedoc/botpress (MIT)

## Overview

This document covers tutorial — developers for the Anticloud integration of BOTPRESS.

Conversational AI platform

## Anticloud Integration

PAX L5 Narrow L2 General 27B is integrated into BOTPRESS to provide:
- Local AI inference with zero cloud dependency
- AIOSS tamper-evident audit chain
- AES-256 encryption at rest
- Single-binary deployment

## Contact

Lois-Kleinner Alpasan — CEO & CTO, Anticloud FZ LLE
lois@0-1.gg | 0-1.gg
